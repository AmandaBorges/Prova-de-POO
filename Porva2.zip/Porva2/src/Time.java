public class Time {

    private String nomeTime;
    private String corTime;

    private String tecnicoTime;


    public String getNomeTime() {
        return nomeTime;
    }

    public void setNomeTime(String nomeTime) {
        this.nomeTime = nomeTime;
    }

    public String getCorTime() {
        return corTime;
    }

    public void setCorTime(String corTime) {
        this.corTime = corTime;
    }


    public String getTecnicoTime() {
        return tecnicoTime;
    }

    public void setTecnicoTime(String tecnicoTime) {
        this.tecnicoTime = tecnicoTime;
    }
}
